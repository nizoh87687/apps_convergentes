package co.edu.unipiloto.lista;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private Spinner spinner;
    private TextView opciones;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        opciones = (TextView) findViewById(R.id.opciones);
        spinner = (Spinner) findViewById(R.id.spinner);

        String[] cervezas = {"negra", "roja", "amarilla", "ambar", "blanca" };
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, cervezas);
        spinner.setAdapter(adapter);
    }

    public void mostrar(View view) {
        String seleccionado = spinner.getSelectedItem().toString();
        if (seleccionado.equals("información")) {
            opciones.setText("puesto sanitario\n " +
                    "puesto telefonico\n " +
                    "estación de servicio\n");
        } else if (seleccionado.equals("reglamentarias")) {
            opciones.setText("pare\n" +
                    "no pase\n " +
                    "prohibido cruzar\n");

        } else if (seleccionado.equals("preventivas")) {
            opciones.setText("cruce\n " +
                    "via lateral izquierda\n " +
                    "via lateral derecha\n ");
        } else if (seleccionado.equals("ambar")) {
            opciones.setText("san miguel\n " +
                    "leffe\n" +
                    "hijos de rivera\n");
        } else if (seleccionado.equals("blanca")) {
            opciones.setText("heineken\n " +
                    "holbrand\n" +
                    "malton\n " );
        }
    }
}